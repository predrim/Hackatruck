//
//  ContentView.swift
//  ProjetoFinal
//
//  Created by Turma01-28 on 13/05/25.
//

import SwiftUI

struct PlanoAlimentar: View {
    
    @StateObject var viewModel = ViewModel()
    @State var recebe: DietaData?
    
    @State var isExpanded1 = false
    @State var dietaExpandida: String? = nil
    
    @ObservedObject var globalData = GlobalData.compartilhada
    @State var checkBoxNome: [CheckboxItem] = []
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.honeydew)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        GroupBox(label: Text("Dietas")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 5)) {
                                
                                DisclosureGroup(isExpanded: $isExpanded1) {
                                    ForEach(viewModel.dietaData, id: \.self) { grupo in
                                        ForEach(grupo.dietas, id: \.self) { dieta in
                                            HStack {
                                                Image(systemName: "play.fill")
                                                    .onTapGesture {
                                                        globalData.tituloDieta = dieta.nomeDieta
                                                    }
                                                DietaView(dieta: dieta, dietaExpandida: $dietaExpandida)
                                            }
                                        }
                                    }
                                } label: {
                                    Text("Mostrar Dietas")
                                        .font(.body)
                                        .foregroundColor(.primary)
                                }
                            }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(radius: 4)
                    .padding(.top, 20)
                }
                .padding(.horizontal)
            }
        }
        .onAppear {
            viewModel.fetch()
        }
        .navigationTitle("Plano Alimentar")
    }
}

#Preview {
    PlanoAlimentar()
}
