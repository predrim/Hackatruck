//
//  Tela_inicial_PJFINALApp.swift
//  Tela_inicial_PJFINAL
//
//  Created by Turma01-23 on 13/05/25.
//

import SwiftUI

@main
struct Tela_inicial_PJFINALApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
