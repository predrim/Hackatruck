//
//  SwiftUIView.swift
//  Tela_inicial_PJFINAL
//
//  Created by Turma01-23 on 21/05/25.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
