//
//  Model.swift
//  ProjetoFinal
//
//  Created by Turma01-28 on 13/05/25.
//

import Foundation


struct DietaData: Codable, Hashable {
    var dietas: [Dieta]
}

struct Dieta: Codable, Hashable {
    var nomeDieta: String
    var descricao: String
    var planoDiario: [Refeicao]
}

struct Refeicao: Codable, Hashable {
    var refeicao: String
    var nomeReceita: String
    var imagem: String
    var ingredientes: [String]
    var calorias: Int
}
