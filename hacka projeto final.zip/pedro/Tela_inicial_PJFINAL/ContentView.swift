
import SwiftUI

struct ContentView: View {
    var body: some View {
        
        TabView {
            inicial()
                .tabItem{
                    Label("Início", systemImage:"house.fill")
                }
            
            PlanoAlimentar()
                .tabItem{
                    Label("Dietas", systemImage: "fork.knife")
                }
            
            missoes()
                .tabItem{
                    Label("Missões", systemImage: "star.leadinghalf.fill")
                }
            
            PerfilView()
                .tabItem{
                    Label("Perfil", systemImage: "person.crop.circle")
                }
            
        }.tint(.darkTeaGreen)
        .onAppear() {
            UITabBar.appearance().backgroundColor = .teaGreen
        }
    }
}




#Preview {
    ContentView()
}
