//
//  missoes.swift
//  Tela_inicial_PJFINAL
//
//  Created by Turma01-23 on 21/05/25.
//

import SwiftUI
import WebKit

struct GifImage: UIViewRepresentable {
    private let name: String

    init(_ name: String) {
        self.name = name
    }

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        if Bundle.main.url(forResource: name, withExtension: "gif") != nil {
            let url = Bundle.main.url(forResource: name, withExtension: "gif")!
            let data = try! Data(contentsOf: url)
            webView.load(
                data,
                mimeType: "image/gif",
                characterEncodingName: "UTF-8",
                baseURL: url.deletingLastPathComponent()
            )
            webView.scrollView.isScrollEnabled = false
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.reload()
    }

}

struct inicial: View {
    @State var totalPontos: Int = 0
//    @State var totalPontos: Int = 0
    @State var mood = ""
    @State var plantHealth = ""
    @State var moveCloud1 = false
    @State var moveCloud2 = false
    @State private var sunSpin = false

    
    var body: some View {
        
        NavigationStack{
            ZStack {
                VStack{
                    
                    switch mood {
                    case "sad":
                        GifImage("rain")
                            .frame(width: 300,height: 300)
                            .offset(x:23, y:100)
                    case "neutral":
                        ZStack{
                            Rectangle()
                                .foregroundColor(.skyBlue)
                            Image("bush")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100)
                                .offset(x:170,y: 10)
                            Image("bush")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 90)
                                .offset(x:30)
                            Image("cloud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200)
                                .offset(x: moveCloud2 ? 300 : -100, y: -110)
                                .onAppear {
                                    moveCloud2 = false
                                    animateCloud2()
                                }
                            Image("cloud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 140)
                                .offset(x: moveCloud1 ? 300 : -100, y: -110)
                                .onAppear {
                                    moveCloud1 = false
                                    animateCloud1()}
                                }
                    case "happy":
                        ZStack{
                            Rectangle()
                                .foregroundColor(.skyBlue)
                            Image("bush")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100)
                                .offset(x:170,y: 10)
                            Image("bush")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 90)
                                .offset(x:30)
                            Image("sun")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 70)
                                .rotationEffect(.degrees(sunSpin ? 360 : 0))
                                .onAppear {
                                    withAnimation(Animation.linear(duration: 15).repeatForever(autoreverses: false)) {
                                        sunSpin = true
                                    }
                                }
                                .offset(x: 100, y: -170)
                            Image("cloud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 140)
                                .offset(x: moveCloud1 ? 300 : -100, y: -110)
                                .onAppear {
                                    moveCloud1 = false
                                    animateCloud1()}
                        }
                        
                    default:
                        GifImage("rain")
                            .frame(width: 300,height: 300)
                            .offset(x:23, y:100)
                    }
                        
                        
                        Spacer()
                    
                }
                Image("background")
                    .resizable()
                    .frame(width: 448,height: 686)
                VStack {
                    Image("titulo2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 130)
                        .padding(.top, 60)
                    
                    
                    
                    ZStack {
                        Image("barra2")
                            .resizable()
                            .frame(width: 280, height: 55)
                        
                        
                        Image(mood)
                            .resizable()
                            .frame(width: 53, height: 50)
                            .offset(x:14*CGFloat(totalPontos))
                    }.padding(.top, -20)
                    Spacer()
                    Image(plantHealth)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 320)
                        .padding()
                        .offset(y:-60)
                }
                
            }.onAppear(){
                moodControl()
                plantHealthControl()
                totalPontos =  globalVariable.Bau
            }
        }
    }
    
    func moodControl(){
        switch totalPontos {
        case (-10)...(-4) :
            mood = "sad"
        case (-6)...3 :
            mood = "neutral"
        case 3...10 :
            mood = "happy"
        default:
            mood = "neutral"
        }
    }
    
    func plantHealthControl() {
        switch totalPontos {
        case (-10)...(-4) :
            plantHealth = "sadSF"
        case (-6)...3 :
            plantHealth = "neutralSF"
        case 3...10 :
            plantHealth = "happySF"
        default:
            plantHealth = "neutralSF"
        }
    }
    
    func animateCloud1() {
        moveCloud1 = false
        withAnimation(Animation.linear(duration: 15)) {
            moveCloud1 = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
            moveCloud1 = false
            animateCloud1()}
    }
    
    func animateCloud2() {
        moveCloud2 = false
        withAnimation(Animation.linear(duration: 25)) {
            moveCloud2 = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 25) {
            moveCloud2 = false
            animateCloud2()}
    }
}

#Preview {
    inicial()
}

