
import SwiftUI

struct PerfilView: View {
    let usuario = Usuario (nome: "Rita Fernandes", idade: 33, altura: 180, peso: 70, sexo: "Feminino", dieta: "Zero Lactose", foto: "fotoperfil")

    struct Usuario {
        var nome: String
        var idade: Int
        var altura: Int
        var peso: Int
        var sexo: String
        var dieta: String
        var foto: String
    }
    
    var body: some View {
        ScrollView {
            ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: [Color("teagreen"), Color.white]),
                        startPoint: .top,
                        endPoint: .bottom)
                
                VStack(spacing: 20) {
                    Image(usuario.foto)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 4))
                        .shadow(radius: 10)
                    
                    Spacer()
                    
                    Text(usuario.nome)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Idade: \(usuario.idade) anos")
                        Text("Altura: \(usuario.altura) cm")
                        Text("Peso: \(usuario.peso) kg")
                        Text("Sexo: \(usuario.sexo)")
                    }
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                    
                    Spacer()

                }
                .padding(.top, 40)
            }
            
        }
        .navigationTitle("Perfil")
        .navigationBarTitleDisplayMode(.inline)
        .ignoresSafeArea()
    }
}


#Preview {
    PerfilView()
}
