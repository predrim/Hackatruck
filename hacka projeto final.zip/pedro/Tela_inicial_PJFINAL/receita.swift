//
//  Descricao.swift
//  ProjetoFinal
//
//  Created by Turma01-23 on 22/05/25.
//

import SwiftUI

struct receita: View {
    
    let receita: Dieta?
    
    var body: some View {
        ZStack {
            Color("honeydew")
                .ignoresSafeArea()
            if let receita = receita,
               let refeicao = receita.planoDiario.first {
                ScrollView {
                    VStack {
                        
                        HStack {
                            Text(refeicao.nomeReceita)
                                .font(.system(size: 40))
                            Spacer()
                        }.padding()
                        
                        VStack {
                            AsyncImage(url: URL(string: refeicao.imagem))
                            { image in image
                                    .resizable()
                                    .scaledToFill()
                                    .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            } placeholder: {
                                Color.gray
                            }
                            .frame(width: 300)
                            .cornerRadius(10)
                            Text("Sobre")
                                .font(.system(size: 20))
                        }
                        
                        VStack {
                            HStack {
                                Text("Ingrediente: \(refeicao.ingredientes.joined(separator: ", "))")
                                    .padding()
                                    .background(Color("teaGreen"))
                                    .cornerRadius(10)
                                    .lineLimit(3)
                                Spacer()
                            }.padding()
                            
                            HStack {
                                Text("Descrição: \(receita.descricao)")
                                    .padding()
                                    .background(Color("teaGreen"))
                                    .cornerRadius(10)
                                Spacer()
                            }.padding()
                            
                            HStack {
                                Text("Calorias: \(refeicao.calorias)")
                                    .padding()
                                    .background(Color("teaGreen"))
                                    .cornerRadius(10)
                                Spacer()
                            }.padding()
                        }.padding()
                        
                        Spacer()
                    }
                }
                } else {
                    Text("Receita não disponível")
                        .font(.title)
                }
            }
        }
    }


#Preview {
    let exemplo = Dieta(
        nomeDieta: "Dieta Balanceada",
        descricao: "Dieta com todos os grupos alimentares equilibrados",
        planoDiario: [
            Refeicao(
                refeicao: "Café da Manhã",
                nomeReceita: "Omelete com espinafre",
                imagem: "",
                ingredientes: ["Ovos", "Espinafre", "Sal", "Azeite"],
                calorias: 250
            )
        ]
    )
    
    return receita(receita: exemplo)
}
