import SwiftUI

struct DietaView: View {
    var dieta: Dieta
    @Binding var dietaExpandida: String?
    
    var body: some View {
        DisclosureGroup(
            dieta.nomeDieta,
            isExpanded: Binding(
                get: { dietaExpandida == dieta.nomeDieta },
                set: { expanded in
                    dietaExpandida = expanded ? dieta.nomeDieta : nil
                }
            )
        ) {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(dieta.planoDiario, id: \.self) { plano in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(plano.refeicao)
                            .font(.headline)
                        
                        NavigationLink(
                            destination: receita(
                                receita: Dieta(
                                    nomeDieta: dieta.nomeDieta,
                                    descricao: dieta.descricao,
                                    planoDiario: [plano]
                                )
                            )
                        ) {
                            Text(plano.nomeReceita)
                                .foregroundColor(.blue)
                        }
                    }
                    Divider()
                }
            }
            .padding()
            .background(Color(.systemMint).opacity(0.1))
            .cornerRadius(8)
        }
        .padding()
        .background(Color(.teaGreen).opacity(0.3))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.bottom, 8)
    }
}

#Preview {

        DietaView(
            dieta: Dieta(
                nomeDieta: "Dieta Exemplo",
                descricao: "Dieta balanceada para energia e saúde.",
                planoDiario: [
                    Refeicao(
                        refeicao: "Café da Manhã",
                        nomeReceita: "Panqueca de aveia",
                        imagem: "",
                        ingredientes: ["Aveia", "Banana", "Ovo"],
                        calorias: 350
                    ),
                    Refeicao(
                        refeicao: "Almoço",
                        nomeReceita: "Frango grelhado com quinoa",
                        imagem: "",
                        ingredientes: ["Frango", "Quinoa", "Brócolis"],
                        calorias: 550
                    ),
                    Refeicao(
                        refeicao: "Jantar",
                        nomeReceita: "Sopa de legumes",
                        imagem: "",
                        ingredientes: ["Cenoura", "Batata", "Abobrinha"],
                        calorias: 300
                    )
                ]
            ),
            dietaExpandida: .constant(nil)
        )
    }


