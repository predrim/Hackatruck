import SwiftUI

struct globalVariable {
    public static var Bau = 0
    
}

// Modelo da missão com dois botões:
struct CheckboxItem: Identifiable {
    var id: UUID                //unico
    var name: String
    var isChecked: Bool      //  Ganha pontos
    var isFailed: Bool       //  Perde pontos
    var points: Int
    var pontuado: Bool = false
    var penalizado: Bool = false
}

// Componente de cada item com dois botões
struct CheckboxViews: View {
    @Binding var totalPontos: Int
    @Binding var item: CheckboxItem
    var onUpdate: () -> Void
    
    @ObservedObject var globalData = GlobalData.compartilhada
    
    var body: some View {
        HStack {
            Text(item.name)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            //  Check positivo
            Image(systemName: item.isChecked ? "checkmark.circle.fill" : "circle")
                .foregroundColor(item.isChecked ? .blue : .gray)
                .font(.system(size: 22))
                .onTapGesture {
                    guard !item.isFailed else { return }

                    item.isChecked.toggle()
                    if item.isChecked && !item.pontuado {
                        totalPontos += item.points
                        item.pontuado = true
                    } else if !item.isChecked && item.pontuado {
                        totalPontos -= item.points
                        item.pontuado = false
                    }
                    onUpdate()
                }

            //  Check negativo
            Image(systemName: item.isFailed ? "xmark.circle.fill" : "circle")
                .foregroundColor(item.isFailed ? .red : .gray)
                .font(.system(size: 22))
                .onTapGesture {
                    guard !item.isChecked else { return }

                    item.isFailed.toggle()
                    if item.isFailed && !item.penalizado {
                        totalPontos -= item.points
                        item.penalizado = true
                    } else if !item.isFailed && item.penalizado {
                        totalPontos += item.points
                        item.penalizado = false
                    }
                    onUpdate()
                }
        }
        .padding()
        .onAppear() {
            for i in globalData.receitaDieta {
                item.name = i.nomeReceita
            }
        }
    }
}

// Tela principal
// Tela principal
struct missoes: View {
    @State private var totalPontos: Int = 0
    @State var items: [CheckboxItem] = []
    
    @ObservedObject var globalData = GlobalData.compartilhada

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.honeydew)
                    .ignoresSafeArea()
                VStack {
                    ScrollView {
                        Text(globalData.tituloDieta)
                            .font(.headline)
                            .padding(.bottom, 10)
                        ForEach($items) { $item in
                            CheckboxViews(totalPontos: $totalPontos, item: $item, onUpdate: {})
                                .background(Color(.teaGreen))
                                .frame(width: 350)
                                .cornerRadius(10)
                        }
                    }
                    .navigationTitle("Missões")

                    VStack {
                        HStack {
                            VStack {
                                Button(action: {
                                    globalVariable.Bau = totalPontos
                                    print(globalVariable.Bau)
                                }) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 60))
                                }
                                .frame(height: 70)
                                .background(Color.honeydew)
                                .padding()
                                .foregroundColor(.teaGreen)
                                .cornerRadius(10)
                            }
                            
                            Spacer()
                            NavigationLink(destination: PlanoAlimentar()) {
                                Image(systemName: "magnifyingglass.circle.fill")
                                    .font(.system(size: 60))
                                    .foregroundStyle(.teaGreen)
                                    .frame(width: 100, height: 100)
                            }
                        }
                    }

                   
                }
            }
        }
        .onAppear {
            items = loadItems()
        }
        .onChange(of: totalPontos) { newValue in
            if totalPontos > 10 {
                totalPontos = 10
            } else if totalPontos < -10 {
                totalPontos = -10
            }
        }
    }

    func loadItems() -> [CheckboxItem] {
        return [
            CheckboxItem(id: UUID(), name: "Café da Manhã", isChecked: false, isFailed: false, points: 2),
            CheckboxItem(id: UUID(), name: "Lanche da Manhã", isChecked: false, isFailed: false, points: 2),
            CheckboxItem(id: UUID(), name: "Almoço", isChecked: false, isFailed: false, points: 2),
            CheckboxItem(id: UUID(), name: "Lanche da tarde", isChecked: false, isFailed: false, points: 2),
            CheckboxItem(id: UUID(), name: "Janta", isChecked: false, isFailed: false, points: 1),
            CheckboxItem(id: UUID(), name: "Lanche da noite", isChecked: false, isFailed: false, points: 1),
        ]
    }
}



// Pré-visualização
#Preview {
    missoes()
}

